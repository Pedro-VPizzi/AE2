/******************************************************************************

Pedro Vinicios Pizzi
ex 5 

*******************************************************************************/
#include <stdio.h>

void estaEntre(char caracter){
    if(caracter > 65 &&caracter < 122){
        printf("O caracter esta entre A e Z");
    }else{
        printf("O caracter não esta entre A e Z");
    }
}

int main(){
    char caracter;
    
    printf("Digite um caracter: ");
    scanf("%c",&caracter);
    
    estaEntre(caracter);
    return 0;
}
