/******************************************************************************

Pedro Vinicios Pizzi
ex 6

*******************************************************************************/
#include <stdio.h>
void desenha (int x){
  for(int i=1; i<=x; i++){
    printf("*");
  }    
}

int main(){
    int x=5;
    printf("O desenho fica dessa forma:\n");
    desenha(x);

    return 0;
}
