/******************************************************************************

Pedro Vinicios Pizzi
ex 4

*******************************************************************************/
#include <stdio.h>

float saldoConta(float saldo){
    return saldo;
}

float deposito(float saldo, float valor){
    printf("Digite o valor a ser depositado: ");
    scanf("%f",&valor);
    
    saldo+=valor;
    return saldo;
}

float saque(float saldo, float valor){
    printf("Digite o valor a ser sacado: ");
    scanf("%f",&valor);
    
    while(saldo > 0){
        if(saldo >= valor){
            saldo-=valor;
            return saldo;
        }else{
            printf("Saldo insuficiente, tente outro valor");
        }
    }
}

int main(){
    float valor = 0;
    float saldo = 0;
    int opcao = 0; 
    
    while(opcao !=4){
        printf("Digite a opcao: ");
        scanf("%d",&opcao);
    
    //saldo
    if(opcao == 1){
        printf("O saldo da sua conta é:%f\n", saldoConta(saldo));
    }
    
    //deposito
    if(opcao == 2){
        saldo+=deposito(saldo,valor);
        printf("Deposito bem sucedido, o saldo atual da sua conta é:%f\n", deposito(saldo, valor));
    }
    
    //saque
    if(opcao == 3){
        saldo-=saque(saldo,valor);
        printf("Saque bem sucedido, o saldo atual da sua conta é:%f\n", saque(saldo, valor));
    }
    
    //erro
    if(opcao < 1 || opcao > 4){
        printf("Opcao invalida! Escolha uma opcao entre 1 e 4\n");
    }
    
    }

    return 0;    
}


//pro, eu queria colocar uma mensgem no deposito e no saque, dizendo que foi realizado com sucesso, mas ele ta pedindo 2 vezes o valor de ambas funções e no saque, não aparece a mensagem de confirmação e saldo restante. Pode me expicar o que estou fazendo errado? Obrigado!



